# Click on Steps Changelog

## v1.3.0

- update 2.2074
- disabled Windows support
- added some options to help with input latency

## v1.2.0

- port to 2.206 (thank you mat for Windows offsets)

Note: Windows 2.206 currently has some new compatibility issues (for example, with custom keybinds)

## v1.1.0

- initial Windows support
- initial Android support
- fix custom keybinds compatibility

## v1.0.0

- initial release
